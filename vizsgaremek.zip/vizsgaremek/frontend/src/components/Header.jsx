import { Link } from "react-router-dom";
import "./Header.css";

export default function Header() {
  return (
    <header className="header">
      <h1 className="logo">React Router Weboldal</h1>
      <nav className="nav">
        <Link to="/">Home</Link>
        <Link to="/about">Rólunk</Link>
        <Link to="/contact">Kapcsolat</Link>
        <Link to="/temps">Hőmérséklet</Link>
      </nav>
    </header>
  );
}
