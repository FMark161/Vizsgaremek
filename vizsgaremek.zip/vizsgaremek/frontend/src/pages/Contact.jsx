import "./Contact.css";

export default function Contact() {
  return (
    <div className="page contact">
      <h2>Kapcsolat</h2>
      <p>Email: info@example.com</p>
      <p>Telefon: +36 30 123 4567</p>
    </div>
  );
}
