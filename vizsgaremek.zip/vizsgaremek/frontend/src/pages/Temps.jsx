import temps from "../data/temps.json";
import "./Temps.css";

export default function Temps() {
  return (
    <div className="page temps">
      <h2>Heti hőmérsékletek</h2>
      <p className="temps-info">
       
      </p>

      <table className="temps-table">
        <thead>
          <tr>
            <th>Nap</th>
            <th>Minimum (°C)</th>
            <th>Maximum (°C)</th>
          </tr>
        </thead>
        <tbody>
          {temps.map((t, index) => (
            <tr key={index}>
              <td>{t.day}</td>
              <td>{t.min}</td>
              <td>{t.max}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
