import "./Home.css";

export default function Home() {
  return (
    <div className="page home">
      <h2>Főoldal</h2>
      <p>Üdvözlünk a React Router alapú weboldalon!</p>
    </div>
  );
}
