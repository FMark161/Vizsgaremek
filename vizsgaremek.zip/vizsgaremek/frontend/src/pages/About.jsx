import "./About.css";

export default function About() {
  return (
    <div className="page about">
      <h2>Rólunk</h2>
      <p>
        Ez az oldal bemutatja, hogyan lehet külön komponensekből és külön CSS
        fájlokból több oldalas React alkalmazást készíteni.
      </p>
    </div>
  );
}
