import "./home.css";



export default function home() {
  const [count, setCount] = useState(0)

  return (
    <>
      <h1>Welcome to főoldal</h1>
    </>
  )
}


