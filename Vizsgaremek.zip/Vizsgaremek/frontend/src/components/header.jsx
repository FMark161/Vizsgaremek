import { Link } from "react-router-dom";
import "./header.css";

export default function header() {
    return (
        <header className="header">
            <h1 className="logo">HarmóniaZene</h1>
            <nav className="nav">
                <Link to="/">Kezdőlap</Link>
                <Link to="/contact">Kapcsolat</Link>
            </nav>
        </header>
    );
}