import { useState } from 'react'
import './App.css'
import Home from './pages/home.jsx';
import { Routes, Route } from 'react-router-dom';
import Header from './components/header.jsx';
import Contact from './pages/contact.jsx';

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div className="app">
        <Header />
        <main className="main">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </main>
      </div>
       
    </>
  )
}

export default App
