import React from "react";
import "./Navbar.css";

function Navbar({ onLogin, onRegister }) {
    return (
        <nav className="navbar navbar-expand-lg navbar-light fixed-top">
            <div className="container">
                <a className="navbar-brand me-4" href="#">
                    <img
                        src="logo.png"
                        alt="Harmónia Zeneiskola logó"
                        className="logo-img"
                    />
                    <span className="brand-text">
                        Harmónia<span>Zene</span>
                    </span>
                </a>

                <button
                    className="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarNav"
                >
                    <span className="navbar-toggler-icon"></span>
                </button>

                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav mx-auto">
                        <li className="nav-item">
                            <a className="nav-link active" href="#">
                                Kezdőlap
                            </a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">
                                Kurzusok
                            </a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">
                                Tanárok
                            </a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">
                                Hangszerek
                            </a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">
                                Kölcsönzés
                            </a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">
                                Események
                            </a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">
                                Kapcsolat
                            </a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">
                                Admin
                            </a>
                        </li>
                    </ul>

                    <div className="d-flex gap-2">
                        <button className="btn btn-secondary-custom" onClick={onLogin}>
                            Bejelentkezés
                        </button>
                        <button className="btn btn-primary" onClick={onRegister}>
                            Regisztráció
                        </button>
                    </div>
                </div>
            </div>
        </nav>
    );
}

export default Navbar;
